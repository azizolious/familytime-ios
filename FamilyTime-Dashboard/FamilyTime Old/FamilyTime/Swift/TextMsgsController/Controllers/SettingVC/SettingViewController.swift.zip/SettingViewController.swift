//
//  LeftSidePanelVC.swift
//  FamilyTime
//
//  Created by YumyApps on 29/10/2021.
//  Copyright © 2021 YumyApps. All rights reserved.
//

import UIKit

class SettingViewController: BaseViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    let delegate = UIApplication.shared.delegate as? AppDelegate
    var dataSource = NSDictionary()
    var doublePushFlag = false
    var placesCont = SwiftPlacesViewController()
    var contactWListCont = SwiftContactsWatchListViewController()
    var allKeys = [String]()
    var package_id : String = ""
    var package_name : String = ""
    var device : String = ""
    var child_DataArr = [ChildData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "settings_title".localized
        let child_Id = UserDefaults.standard.string(forKey: UserDefaultsConstants.SELECTED_CHILD_ID) ?? ""
        let obj = CoreDataUtility.fetchChildInfoFromDatabase(child_id: child_Id)
//        print("child = \(String(describing: delegate?.selectedDashboardChild)) and features = \(String(describing: delegate?.selectedDashboardChild.package_features))")

        placesCont = SwiftPlacesViewController(nibName: "PlacesViewController", bundle: nil)
        let data = CoreDataUtility.fetchDashboardFromDatabase()
        print(data)
        self.child_DataArr = data
        tableView.reloadData()
        contactWListCont = SwiftContactsWatchListViewController(nibName: "ContactsWatchListViewController", bundle: nil)
        tableView.register(UINib(nibName: "LeftSidesTableViewCell", bundle: nil), forCellReuseIdentifier: "LeftSidesCell")
        tableView.rowHeight = 75
        tableView.separatorStyle = .none
        self.allKeys = ["settings_card_1_title", "settings_card_2_title", "settings_card_3_title", "settings_card_4_title", "settings_card_5_title"]
        
        package_id = CoreDataUtility.fetchPackageIdFor(child_id: Int32(child_Id) ?? 0)
        package_name = CoreDataUtility.fetchPackageNameFor(child_id:  Int32(child_Id) ?? 0)
        device = CoreDataUtility.fetchPackageDeviceFor(child_id:  Int32(child_Id) ?? 0)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        ZDCChat.instance().api.trackEvent("Settings android device")

        let filePath = Bundle.main.path(forResource: "settings", ofType: "plist")
        
        if let data = NSDictionary(contentsOfFile: filePath ?? "") {
            
            self.dataSource = data
            
        }
    
        tableView.reloadData()
        self.doublePushFlag = false
        
    }
    
    @objc func updatePreference(_ indexPath: IndexPath?, value: Int) {
        
        var name: String?
        var includeUserId = true
        var isNotification = false //---FLAG TO HIT NOTIF API FOR SETTINGS---//

        if indexPath?.section == 0 && indexPath?.row == 0 {
            name = "call_logs"
            includeUserId = false
        } else if indexPath?.section == 0 && indexPath?.row == 1 {
            name = "sms_logs"
            includeUserId = false
        } else if indexPath?.section == 0 && indexPath?.row == 2 {
            name = "contact_logs"
            includeUserId = false
        } else if indexPath?.section == 0 && indexPath?.row == 3 {
            name = "location_tracking"
            includeUserId = false
        } else if indexPath?.section == 0 && indexPath?.row == 4 {
            name = "installed_app_logs"
            includeUserId = false
        } else if indexPath?.section == 0 && indexPath?.row == 5 {
            name = "safe_internet"
            includeUserId = false
        } else if indexPath?.section == 2 && indexPath?.row == 0 {
            name = "monitor_places_alert"
            includeUserId = true
            isNotification = true
        } else if indexPath?.section == 2 && indexPath?.row == 1 {
            name = "app_blocking_alert"
            includeUserId = true
            isNotification = true
        } else if indexPath?.section == 2 && indexPath?.row == 2 {
            name = "contact_watchlist_alert"
            includeUserId = true
            isNotification = true
        } else if indexPath?.section == 3 && indexPath?.row == 2 {
            name = "top_stack"
            includeUserId = false
            isNotification = false
        }
        
        var params: [String : Any] = [:]
        let userID = UserDefaults.standard.string(forKey: "userID")
        if includeUserId {
            
            params = [
                "name": name ?? "",
                "status": NSNumber(value: value),
                "value": String(format: "%i", value),
                "user_id": userID
            ]
            
        } else {
            
            params = [
                "name": name ?? "",
                "status": NSNumber(value: value),
                "value": String(format: "%i", value)
            ]
            
        }
        
        print("params = \(params)")
        CommonModel.updatePreference(params, view: self, isNotification: isNotification)
        
    }
    
    func showPremiumAlert() {
        
        SwiftFTUtils.showSwiftPremiumPopup(on: self)
        
    }
    
//MARK: - TableView Data Sourse and Delegate
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let frame = UIScreen.main.bounds
        let view = UIView(frame: CGRect(x: 10, y: 10, width: frame.size.width, height: 40))
        view.backgroundColor = UIColor.white
        let headertitle = UILabel()
        headertitle.frame = CGRect.init(x: 10, y: 15, width: tableView.frame.width-20, height: 30)
        
        if section == 0 {
            headertitle.textColor = CommonModel.color(fromHexString: "orange")
        } else if section == 1 {
            headertitle.textColor = CommonModel.color(fromHexString: "green")
        } else if section == 2 {
            headertitle.textColor = CommonModel.color(fromHexString: "purple")
        } else if section == 3 {
            headertitle.textColor = CommonModel.color(fromHexString: "red")
        } else {
            headertitle.textColor = CommonModel.color(fromHexString: "orange")
        }
        
        headertitle.text = allKeys[section]
        headertitle.font = UIFont(name: "OpenSans", size: 20.0)
        headertitle.text = headertitle.text?.myModification()
        view.addSubview(headertitle)
        return view
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dataSource.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (dataSource.value(forKey: allKeys[section]) as AnyObject).count ?? 0
    
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "LeftSidesCell") as? SettingTableViewCell
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "LeftSidesCell") as? SettingTableViewCell
        }
        let key = allKeys[indexPath.section]
        let items = dataSource.value(forKey: key) as? [AnyHashable]
        
        var label = ""
        var lImgName = ""
        var rImgName = ""
        
        if let item = items?[indexPath.row] as? NSDictionary {
            
            label = item["label"] as! String
            lImgName = item["lefticon"] as! String
            rImgName = item["righticon"] as! String
            
        }

        cell?.cellImage.image = UIImage(named: lImgName)
        
        if rImgName.count > 0 {
//            cell?.cellSwitch = UISwitch(frame: CGRect(x: 0, y: 0, width: 51, height: 31))
//            cell?.accessoryView = cell?.cellSwitch
            cell?.cellSwitch.isHidden = false
//            cell?.arrow.isHidden = true
            let type = UserDefaults.standard.string(forKey: "userType")
            if indexPath.section == 2 && (type == "Super") {
                cell?.cellSwitch.isEnabled = true
            } else if indexPath.section == 2 && (type != "Super") {
                cell?.cellSwitch.isEnabled = false
            }

            setSwitchState(indexPath, cell: cell)
            
            cell?.onSwitchChange = { cellAffected in
                
                if indexPath.section == 0 && indexPath.row == 0 {
                    
                    let indexPath = tableView.indexPath(for: cellAffected!)
                    print(String(format: "Section %ld Row : %ld", Int(indexPath?.section ?? 0), Int(indexPath?.row ?? 0)))
                    
                    var switchStatus = 0
                    
                    if cellAffected?.cellSwitch.isOn == true {
                        
                        switchStatus = 1
                        
                    }
                    
                    self.updatePreference(indexPath, value: switchStatus)
                    
                }
                if indexPath.section == 0 && indexPath.row == 1 {
                    
                    if self.package_id == "5" {
                        
                        let indexPath = tableView.indexPath(for: cellAffected!)
                        print(String(format: "Section %ld Row : %ld", Int(indexPath?.section ?? 0), Int(indexPath?.row ?? 0)))
                        var switchStatus = 0
                        
                        if cellAffected?.cellSwitch.isOn == true {
                            
                            switchStatus = 1
                            
                        }
                        
                        self.updatePreference(indexPath, value: switchStatus)
                        
                    } else {
                        
                        if !self.doublePushFlag {
                            self.doublePushFlag = true
                            self.showPremiumAlert()
                            cellAffected?.cellSwitch.isOn = false
                        }
                        
                    }
                    
                } else if indexPath.section == 0 && indexPath.row == 2 {
                    if self.package_id == "2" || self.package_id == "5" {
                        let indexPath = tableView.indexPath(for: cellAffected!)
                        print(String(format: "Section %ld Row : %ld", Int(indexPath?.section ?? 0), Int(indexPath?.row ?? 0)))
                        
                        var switchStatus = 0
                        if cellAffected?.cellSwitch.isOn == true {
                            
                            switchStatus = 1
                            
                        }
                        
                        self.updatePreference(indexPath, value: switchStatus)
                        
                    } else {
                        
                        if !self.doublePushFlag {
                            self.doublePushFlag = true
                            self.showPremiumAlert()
                            cellAffected?.cellSwitch.isOn = false
                        }
                        
                    }
                    
                } else if indexPath.section == 0 && indexPath.row == 3 {
                    
                    if self.package_id == "2" || self.package_id == "5" {
                        let indexPath = tableView.indexPath(for: cellAffected!)
                        print(String(format: "Section %ld Row : %ld", Int(indexPath?.section ?? 0), Int(indexPath?.row ?? 0)))
                        
                        var switchStatus = 0
                        if cellAffected?.cellSwitch.isOn == true {
                            
                            switchStatus = 1
                            
                        }
                        self.updatePreference(indexPath, value: switchStatus)
                        
                    } else {
                        
                        if !self.doublePushFlag {
                            self.doublePushFlag = true
                            self.showPremiumAlert()
                            cellAffected?.cellSwitch.isOn = false
                        }
                        
                    }
                    
                } else if indexPath.section == 0 && indexPath.row == 4 {
                    
                    let indexPath = tableView.indexPath(for: cellAffected!)
                    print(String(format: "Section %ld Row : %ld", Int(indexPath?.section ?? 0), Int(indexPath?.row ?? 0)))
                    
                    var switchStatus = 0
                    if cellAffected?.cellSwitch.isOn == true {
                        
                        switchStatus = 1
                        
                    }
                    self.updatePreference(indexPath, value: switchStatus)
                    
                }
                else if indexPath.section == 0 && indexPath.row == 5 {
                    
                    if self.package_id == "2" || self.package_id == "5" {
                        let indexPath = tableView.indexPath(for: cellAffected!)
                        print(String(format: "Section %ld Row : %ld", Int(indexPath?.section ?? 0), Int(indexPath?.row ?? 0)))
                        
                        var switchStatus = 0
                        if cellAffected?.cellSwitch.isOn == true {
                            
                            switchStatus = 1
                            
                        }
                        
                        self.updatePreference(indexPath, value: switchStatus)
                        
                    } else {
                        
                        if !self.doublePushFlag {
                            self.doublePushFlag = true
                            self.showPremiumAlert()
                            cellAffected?.cellSwitch.isOn = false
                        }
                        
                    }
                    
                }
                else if indexPath.section == 2 && indexPath.row == 0 {
                    
//                    if self.delegate?.selectedDashboardChild.package_id == 2 || self.delegate?.selectedDashboardChild.package_id == 5 {
                        let indexPath = tableView.indexPath(for: cellAffected!)
                        print(String(format: "Section %ld Row : %ld", Int(indexPath?.section ?? 0), Int(indexPath?.row ?? 0)))
                        
                        var switchStatus = 0
                        if cellAffected?.cellSwitch.isOn == true {
                            
                            switchStatus = 1
                            
                        }
                        self.updatePreference(indexPath, value: switchStatus)
                        
//                    } else {
//
//                        if !self.doublePushFlag {
//                            self.doublePushFlag = true
//                            self.showPremiumAlert()
//                            cellAffected?.cellSwitch.isOn = false
//                        }
//
//                    }
                    
                } else if indexPath.section == 2 && indexPath.row == 1 {
                    
                    if self.package_id == "2" || self.package_id == "5" {
                        let indexPath = tableView.indexPath(for: cellAffected!)
                        print(String(format: "Section %ld Row : %ld", Int(indexPath?.section ?? 0), Int(indexPath?.row ?? 0)))
                        
                        var switchStatus = 0
                        if cellAffected?.cellSwitch.isOn == true {
                            
                            switchStatus = 1
                        }
                        self.updatePreference(indexPath, value: switchStatus)
                        
                    } else {
                        
                        if !self.doublePushFlag {
                            self.doublePushFlag = true
                            self.showPremiumAlert()
                            cellAffected?.cellSwitch.isOn = false
                        }
                    }
                    
                } else if indexPath.section == 2 && indexPath.row == 2 {
                    
                    if self.package_id == "2" || self.package_id == "5" {
                        let indexPath = tableView.indexPath(for: cellAffected!)
                        print(String(format: "Section %ld Row : %ld", Int(indexPath?.section ?? 0), Int(indexPath?.row ?? 0)))
                        
                        var switchStatus = 0
                        if cellAffected?.cellSwitch.isOn == true {
                            
                            switchStatus = 1
                            
                        }
                        self.updatePreference(indexPath, value: switchStatus)
                        
                    } else {
                        
                        if !self.doublePushFlag {
                            self.doublePushFlag = true
                            self.showPremiumAlert()
                            cellAffected?.cellSwitch.isOn = false
                        }
                    }
                } else if indexPath.section == 3 && indexPath.row == 2 {
                    
                    if self.package_id == "2" || self.package_id == "5" {
                        print("hide notification area toggle")
                        let indexPath = tableView.indexPath(for: cellAffected!)
                        print(String(format: "Section %ld Row : %ld", Int(indexPath?.section ?? 0), Int(indexPath?.row ?? 0)))
                        
                        var switchStatus = 0
                        if cellAffected?.cellSwitch.isOn == true {
                            
                            switchStatus = 1
                            
                        }
                        self.updatePreference(indexPath, value: switchStatus)
                        
                    } else {
                        
                        if !self.doublePushFlag {
                            self.doublePushFlag = true
                            self.showPremiumAlert()
                            cellAffected?.cellSwitch.isOn = false
                        }
                        
                    }
                }
                
            } // Cell Affected End Here
            
        } else {
            
            cell?.cellSwitch.isHidden = true
//            cell?.accessoryType = .none
//            cell?.accessoryView = nil
//            cell?.arrow.isHidden = false
            
        }
        
        cell?.cellLabel.text = label.myModification()

        if indexPath.section == 0 {
            cell?.cellSwitch.onTintColor = CommonModel.color(fromHexString: "orange")
        } else if indexPath.section == 2 {
            cell?.cellSwitch.onTintColor = CommonModel.color(fromHexString: "purple")
        } else if indexPath.section == 3 {
            cell?.cellSwitch.onTintColor = CommonModel.color(fromHexString: "red")
        }
        
        return cell ?? UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        let key = allKeys[indexPath.section]
        let items = dataSource.value(forKey: key) as? [AnyHashable]
        
        var label = ""
        
        if let item = items?[indexPath.row] as? NSDictionary {
            
            label = item["label"] as! String
            
        }
        
        if (label == "settings_card_2_android_5") && indexPath.section == 1 {
            
            if self.package_id == "2" || self.package_id == "5" {
                
                navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
                let stb = UIStoryboard(name: "Dashboard", bundle: nil)
                let vc = stb.instantiateViewController(withIdentifier: "InternetFilterVC") as? InternetFilterVC
                        if let vc = vc {
                            navigationController?.pushViewController(vc, animated: true)
                        }
                
            } else {
                
                SwiftFTUtils.showSwiftPremiumPopup(on: self)
                
            }
            
        } else if (label == "settings_card_2_android_4") && indexPath.section == 1 {
            
            if self.package_id == "2" || self.package_id == "5" {
                
                let stb = UIStoryboard(name: "Dashboard", bundle: nil)
                let vc = stb.instantiateViewController(withIdentifier: "InternetScheduleVC") as? InternetScheduleVC
                navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
                if let vc = vc {
                    navigationController?.pushViewController(vc, animated: true)
                }
                
            } else {
                
                SwiftFTUtils.showSwiftPremiumPopup(on: self)
                
            }
            
        } else if (label == "settings_card_2_android_6") && indexPath.section == 1 {
            
            if self.package_id == "2" || self.package_id == "5" {
                
                navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
                navigationController?.pushViewController(placesCont, animated: true)
                
            } else {
                
                SwiftFTUtils.showSwiftPremiumPopup(on: self)
                
            }
            
        } else if (label == "settings_card_2_android_2") && indexPath.section == 1 {
            
            if self.package_id == "2" || self.package_id == "5" {
                
                navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
                let stb = UIStoryboard(name: "Dashboard", bundle: nil)
                let vc = stb.instantiateViewController(withIdentifier: "AppBlockerAndroidVC") as? AppBlockerAndroidVC
                        if let vc = vc {
                            navigationController?.pushViewController(vc, animated: true)
                        }
                
            } else {
                
                SwiftFTUtils.showSwiftPremiumPopup(on: self)
                
            }
            
        } else if (label == "settings_card_2_android_7") && indexPath.section == 1 {
            
            if self.package_id == "2" || self.package_id == "5" {
                
                let storyboardName = "MyStoryboard"
                let storyboard = UIStoryboard(name: storyboardName, bundle: Bundle.main)
                let vc = storyboard.instantiateViewController(withIdentifier: "ClockViewController") as? ClockViewController
                        if let vc = vc {
                            navigationController?.pushViewController(vc, animated: true)
                        }
                
            } else {
                
                SwiftFTUtils.showSwiftPremiumPopup(on: self)
                
            }
            
        } else if (label == "settings_card_2_android_3") && indexPath.section == 1 {
            
            if self.package_id == "2" || self.package_id == "5" {
                
                let stb = UIStoryboard(name: "Dashboard", bundle: nil)
                let vc = stb.instantiateViewController(withIdentifier: "ScheduleScreenTimeVC") as? ScheduleScreenTimeVC
                navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
                if let vc = vc {
                    navigationController?.pushViewController(vc, animated: true)
                }
            } else {
                
                SwiftFTUtils.showSwiftPremiumPopup(on: self)
                
            }
            
        } else if (label == "settings_card_2_android_1") && indexPath.section == 1 {
            
            let packageFeature = delegate?.selectedDashboardChild.getPackageFeature(withName: "daily_limit")

            if packageFeature == nil {

                let vc = AndroidDailyLimitVC()
                navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
                navigationController?.pushViewController(vc, animated: true)
                
            } else if packageFeature?.package_id == 1 {
                
                showPremiumAlert()
                
            } else {
                
                //---NEW SWIFT CONVERTED CLASS---//
                let vc = AndroidDailyLimitVC()
                navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
                navigationController?.pushViewController(vc, animated: true)
                
            }
            
        } else if label == "settings_card_5_1" {
            
            self.synSettings()
            
        } else if (label == "settings_card_2_android_8") && indexPath.section == 1 {
            
            if self.package_id == "2" || self.package_id == "5" {
                
                navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
                navigationController?.pushViewController(contactWListCont, animated: true)
                
            } else {
                
                SwiftFTUtils.showSwiftPremiumPopup(on: self)
                
            }
            
        } else if (label == "settings_android_content_3_sub_content_2") && indexPath.section == 3 {
            
            if self.package_id == "1" {
                
                self.showPremiumAlert()
                
            } else {
                
//                CommonModel.lockPhonePopup(self)
                
                let dashboardStoryboard = UIStoryboard(name: "Dashboard", bundle: nil)
                
                let vc = dashboardStoryboard.instantiateViewController(withIdentifier: "PasscodePopUpViewController") as? PasscodePopUpViewController ?? PasscodePopUpViewController()
                
                vc.color = "red"
                vc.modalPresentationStyle = .overFullScreen
                self.present(vc, animated: true, completion: nil)
                
            }
            
        } else if label == "settings_content_3_sub_content_1" {
            
            SwiftFTUtils.pushDeviceController(on: self)
            
        }
    }
    
    func setSwitchState(_ indexPath: IndexPath?, cell: SettingTableViewCell?) {
        
        cell?.cellSwitch.isOn = false
        if indexPath?.section == 0 && indexPath?.row == 0 {
            
            if self.package_id == "2" || self.package_id == "5" || self.package_id == "1" {
                //call_logs
                //let child_Id = UserDefaults.standard.string(forKey: UserDefaultsConstants.SELECTED_CHILD_ID) ?? ""
                var childDataStrn: ChildData?
                var switchStatus = false
                for i in child_DataArr{
                    childDataStrn = i
                }
                if let data = childDataStrn{
                    let callsPreference = SwiftCommonUtility.shared.getPreferenceWithName(child: data)
                    print(callsPreference?.name)
                    if callsPreference?.name == "sms_logs"{
                        if callsPreference?.status == 1 {
                            switchStatus = true
                        }
                    }
                    
                    cell?.cellSwitch.isOn = switchStatus
                }
                    
                    
                
            } else {
                
                cell?.cellSwitch.isOn = false
            }
            
        } else if indexPath?.section == 0 && indexPath?.row == 1 {
            print("TEST: -\(package_id)")
            if self.package_id == "1" || self.package_id == "2" {
                
                cell?.cellSwitch.isOn = false
                
            } else {
                
                let smsPreference = delegate?.selectedDashboardChild.getPreferencesWithName("sms_logs")
                var switchStatus = false
                
                if smsPreference?.status == 1 {
                    
                    switchStatus = true
                    
                }
                cell?.cellSwitch.isOn = switchStatus
            }
            
        } else if indexPath?.section == 0 && indexPath?.row == 2 {
            
            if self.package_id == "2" || self.package_id == "5" {
                
                let contactsPreference = delegate?.selectedDashboardChild.getPreferencesWithName("contact_logs")
                var switchStatus = false
                
                if contactsPreference?.status == 1 {
                    
                    switchStatus = true
                    
                }
                cell?.cellSwitch.isOn = switchStatus
                
            } else {
                
                cell?.cellSwitch.isOn = false
                
            }
            
        } else if indexPath?.section == 0 && indexPath?.row == 3 {
            
            if self.package_id == "1" {
                
                cell?.cellSwitch.isOn = false
                
            } else {
                
                let locationssPreference = delegate?.selectedDashboardChild.getPreferencesWithName("location_tracking")
                var switchStatus = false
                
                if locationssPreference?.status == 1 {
                    
                    switchStatus = true
                    
                }
                cell?.cellSwitch.isOn = switchStatus
                
            }
            
        }else if indexPath?.section == 0 && indexPath?.row == 4 {
            
//            if delegate?.selectedDashboardChild.package_id == 1 {
//
//                cell?.cellSwitch.isOn = false
//
//            } else {
                
//                let appsPreference = delegate?.selectedDashboardChild.getPreferencesWithName("installed_app_logs")
//                var switchStatus = false
//                if appsPreference?.status == 1 {
//
//                    switchStatus = true
//
//                }
            
            let child_Id = UserDefaults.standard.string(forKey: UserDefaultsConstants.SELECTED_CHILD_ID) ?? ""
            let data = CoreDataUtility.fetchDashboardFromDatabase()
            
            var childDataStrn: ChildData?
            var switchStatus = false
            for i in data{
                childDataStrn = i
            }
            if let data = childDataStrn{
                let callsPreference = SwiftCommonUtility.shared.getPreferenceWithName(child: data)
                if callsPreference?.status == 1 {
                    switchStatus = true
                }
            }
            
                cell?.cellSwitch.isOn = switchStatus
                
//            }
            
        }
        else if indexPath?.section == 0 && indexPath?.row == 5 {

            
            if self.package_id == "1" {

                cell?.cellSwitch.isOn = false

            } else {

//                let locationssPreference = delegate?.selectedDashboardChild.getPreferencesWithName("safe_internet")
//                var switchStatus = false
//
//                if locationssPreference?.status == 1 {
//
//                    switchStatus = true
//
//                }
                let child_Id = UserDefaults.standard.string(forKey: UserDefaultsConstants.SELECTED_CHILD_ID) ?? ""
                let data = CoreDataUtility.fetchDashboardFromDatabase()
                
                var childDataStrn: ChildData?
                var switchStatus = false
                for i in data{
                    childDataStrn = i
                }
                if let data = childDataStrn{
                    let callsPreference = SwiftCommonUtility.shared.getPreferenceWithName(child: data)
                    if callsPreference?.status == 1 {
                        switchStatus = true
                    }
                }
                cell?.cellSwitch.isOn = switchStatus

            }

        }
        else if indexPath?.section == 2 && indexPath?.row == 0 {
            
//            if delegate?.selectedDashboardChild.package_id == 1 {
//
//                cell?.cellSwitch.isOn = false
//
//            } else {
                
                let placesNotification = delegate?.selectedDashboardChild.getNotificationsWithName("monitor_places_alert")
                var switchStatus = false
                
                if placesNotification?.status == 1 {
                    
                    switchStatus = true
                    
                }
                cell?.cellSwitch.isOn = switchStatus
                
//            }
            
        } else if indexPath?.section == 2 && indexPath?.row == 1 {
            
            if self.package_id == "1" {
                
                cell?.cellSwitch.isOn = false
                
            } else {
                
                let appblockingNotification = delegate?.selectedDashboardChild.getNotificationsWithName("app_blocking_alert")
                var switchStatus = false
                
                if appblockingNotification?.status == 1 {
                    
                    switchStatus = true
                    
                }
                cell?.cellSwitch.isOn = switchStatus
                
            }
            
        } else if indexPath?.section == 2 && indexPath?.row == 2 {
            
            if self.package_id == "1" {
                
                cell?.cellSwitch.isOn = false
                
            } else {
                
                let conatcsWatchlistNotification = delegate?.selectedDashboardChild.getNotificationsWithName("contact_watchlist_alert")
                var switchStatus = false
                
                if conatcsWatchlistNotification?.status == 1 {
                    
                    switchStatus = true
                    
                }
                cell?.cellSwitch.isOn = switchStatus
                
            }
            
        } else if indexPath?.section == 3 && indexPath?.row == 2 {
            
            if self.package_id == "1" {
                
                cell?.cellSwitch.isOn = false
                
            } else {
                
                let topStack = delegate?.selectedDashboardChild.getPreferencesWithName("top_stack")
                var switchStatus = false
                
                if topStack?.status == 1 {
                    
                    switchStatus = true
                    
                }
                cell?.cellSwitch.isOn = switchStatus
                
            }
            
        } else {
            
            cell?.cellSwitch.isOn = false
            
        }
    }
    
    func synSettings() {
        
        SwiftFTUtils.showHUDAdded(to: view, withText: "Loading...".myModification(), animated: true)


        let url = String(format: "\(kAndroid_Sync_settings_mesh2)\(Int(delegate?.selectedDashboardChild.child_id ?? -1))")
        let params = [
            "setting": "all"
        ]

        print("url to sync settings = \(url) and params = \(params)")
        
        ApiManager.shared().postApi(withVC: self, isPresentedCont: false, andParams: params, withApi: url) { message, statusCode in
            
            DispatchQueue.main.async {
                
                SwiftFTUtils.hideHUDAdded(to: self.view, animated: true)

                print(String(format: "sync settings status code = %ld and message = %@", Int(statusCode), message))
                CommonModel.showAlert("settings_card_5_1".localized, msg: "sync_alert_content_1".localized)
                
            }
            
        }
        
    }
    
}
